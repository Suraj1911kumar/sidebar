import React from 'react'

const Mail = () => {
  return (
    <div>
      Mail
    </div>
  )
}

export default Mail
