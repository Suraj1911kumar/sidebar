import React, { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { FaBars, FaHome } from "react-icons/fa";
import { NavLink } from "react-router-dom";
import { MdDashboard } from "react-icons/md";
import { CiMail } from "react-icons/ci";
import { CiSearch } from "react-icons/ci";
import { FcAbout } from "react-icons/fc";
const routes = [
  {
    path: "/",
    name: "Home",
    icon: <FaHome />,
  },
  {
    path: "/about",
    name: "About",
    icon: <FcAbout />,
  },
  {
    path: "/dashboard",
    name: "Dashboard",
    icon: <MdDashboard />,
  },
  {
    path: "/mail",
    name: "Mail",
    icon: <CiMail />,
  },
];

const inputAnimation = {
  hidden: {
    width: 0,
    padding: 0,
    opacity: 0,
  },
  show: {
    width: "140px",
    padding: "5px 15px",
    opacity: 1,
    transition: {
      duration: 0.2,
    },
  },
};
const textAnimation = {
  hidden: {
    width: 0,
    opacity: 0,
    transition: {
      duration: 0.5,
    },
  },
  show: {
    width: "auto",
    opacity: 1,
    transition: {
      duration: 0.2,
    },
  },
};
const Sidebar = ({ children }) => {
  const [isOpen, setIsOpen] = useState(false);
  const toggle = () => setIsOpen(!isOpen);

  return (
    <>
      <div className="main-container">
        <motion.div
          animate={{ width: isOpen ? "200px" : "45px" }}
          className="sidebar"
        >
          <div className="top_section">
            <AnimatePresence>
              {isOpen && (
                <motion.h1
                  initial="hidden"
                  animate="show"
                  exit="hidden"
                  variants={textAnimation}
                  className="logo"
                >
                  Dashboard
                </motion.h1>
              )}
            </AnimatePresence>
            <div className="menu-icon">
              <FaBars onClick={toggle} />
            </div>
          </div>
          <div className="search">
            <div className="search-icon">
              <CiSearch />
            </div>
            <AnimatePresence>
              {isOpen && (
                <motion.input
                  initial="hidden"
                  animate="show"
                  exit="hidden"
                  variants={inputAnimation}
                  type="text"
                  placeholder="search..."
                />
              )}
            </AnimatePresence>
          </div>

          <section className="routes">
            {routes.map((routes) => (
              <NavLink activeClassName="active" to={routes.path} key={routes.name} className="link">
                <div className="icon">{routes.icon}</div>
                <AnimatePresence>
                  {isOpen && (
                    <motion.div
                      initial="hidden"
                      animate="show"
                      exit="hidden"
                      variants={textAnimation}
                      className="link-text"
                    >
                      {routes.name}
                    </motion.div>
                  )}
                </AnimatePresence>
              </NavLink>
            ))}
          </section>
        </motion.div>
        <div className="main">{children}</div>
      </div>
    </>
  );
};

export default Sidebar;
